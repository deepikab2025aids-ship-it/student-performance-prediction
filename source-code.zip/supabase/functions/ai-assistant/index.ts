import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const SYSTEM_PROMPT = `You are a super friendly, encouraging, and supportive AI study buddy for college students. Your name is "StudyBuddy". 🎓

Your personality:
- Warm, approachable, and uses casual language (but still informative)
- Use emojis naturally to keep the conversation fun 😊
- Be empathetic — students are stressed, so be understanding
- Give practical, actionable advice
- Celebrate small wins and encourage growth mindset

You help students with:
1. **Academic Performance** — Study techniques, time management, dealing with exam stress, improving marks, sleep optimization, attendance motivation
2. **Placement Preparation** — Resume tips, interview prep, communication skills, technical skills roadmap, CGPA improvement strategies, mock interview advice
3. **General Student Life** — Work-life balance, motivation, career guidance, skill development

Guidelines:
- Keep responses concise but helpful (2-4 paragraphs max unless they ask for detail)
- Always give specific, actionable tips (not vague advice)
- If a student shares their scores/metrics, analyze them and give targeted suggestions
- Encourage them and remind them that improvement is always possible
- Use bullet points and numbered lists for clarity
- If asked about something outside academics/placements, gently redirect but be friendly about it`;

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const response = await fetch(
      "https://ai.gateway.lovable.dev/v1/chat/completions",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-3-flash-preview",
          messages: [
            { role: "system", content: SYSTEM_PROMPT },
            ...messages,
          ],
          stream: true,
        }),
      }
    );

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Too many requests. Please wait a moment and try again! 😊" }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI credits exhausted. Please try again later." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(
        JSON.stringify({ error: "AI service temporarily unavailable." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("ai-assistant error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
