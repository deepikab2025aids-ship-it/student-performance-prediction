import { useNavigate, useLocation } from "react-router-dom";
import { LogOut, LayoutDashboard, TrendingUp, Briefcase, User, BookOpen, GraduationCap, Target, Settings } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import ThemeToggle from "./ThemeToggle";

const navItems = [
  { path: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { path: "/performance", label: "Performance", icon: TrendingUp },
  { path: "/placement", label: "Placement", icon: Briefcase },
  { path: "/planner", label: "Planner", icon: BookOpen },
  { path: "/mock-test", label: "Tests", icon: GraduationCap },
  { path: "/goals", label: "Goals", icon: Target },
  { path: "/profile", label: "Profile", icon: User },
  { path: "/settings", label: "Settings", icon: Settings },
];

const Navbar = () => {
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <nav className="fixed top-0 w-full z-50 border-b border-border glass">
      <div className="max-w-[1400px] mx-auto px-4 h-16 flex items-center justify-between">
        <button onClick={() => navigate("/")} className="text-sm font-bold tracking-tighter uppercase font-display gradient-text">
          Student Predictor
        </button>

        <div className="hidden md:flex items-center gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = location.pathname === item.path;
            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  active
                    ? "gradient-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                }`}
              >
                <Icon size={14} />
                {item.label}
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-2">
          <ThemeToggle />
          <button
            onClick={async () => { await supabase.auth.signOut(); navigate("/login"); }}
            className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
          >
            <LogOut size={14} /> Sign Out
          </button>
        </div>
      </div>

      {/* Mobile nav */}
      <div className="md:hidden flex items-center gap-0.5 px-2 pb-2 overflow-x-auto scrollbar-hide">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = location.pathname === item.path;
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-medium whitespace-nowrap transition-all ${
                active
                  ? "gradient-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Icon size={12} />
              {item.label}
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export default Navbar;
