import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowUpRight, Briefcase, Save, History, Trash2 } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, RadialBarChart, RadialBar, Legend, LineChart, Line } from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const transition = { duration: 0.8, ease: [0.19, 1, 0.22, 1] as const };

type PlacementChance = "High" | "Medium" | "Low" | null;

const chanceColors: Record<string, string> = {
  High: "#22d3a0",
  Medium: "#f5a623",
  Low: "#ef4444",
};

const chanceText: Record<string, string> = {
  High: "Strong placement probability. Your profile is competitive.",
  Medium: "Moderate chances. Focus on improving weaker areas.",
  Low: "Consider strengthening your skills and academics.",
};

interface PredictionRecord {
  id: string;
  inputs: { cgpa: number; communication: number; technical: number };
  result: string;
  score: number;
  created_at: string;
}

const PlacementPrediction = () => {
  const [cgpa, setCgpa] = useState("");
  const [communication, setCommunication] = useState("");
  const [technical, setTechnical] = useState("");
  const [result, setResult] = useState<PlacementChance>(null);
  const [score, setScore] = useState<number | null>(null);
  const [chartData, setChartData] = useState<any[]>([]);
  const [history, setHistory] = useState<PredictionRecord[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    const { data } = await supabase
      .from("predictions")
      .select("*")
      .eq("type", "placement")
      .order("created_at", { ascending: false });
    if (data) setHistory(data as unknown as PredictionRecord[]);
  };

  const predict = () => {
    const c = Math.min(Math.max(parseFloat(cgpa) || 0, 0), 10);
    const comm = Math.min(Math.max(parseFloat(communication) || 0, 0), 100);
    const tech = Math.min(Math.max(parseFloat(technical) || 0, 0), 100);

    const s = (c * 10 + comm + tech) / 3;
    setScore(s);
    if (s >= 75) setResult("High");
    else if (s >= 60) setResult("Medium");
    else setResult("Low");

    setChartData([
      { name: "CGPA", value: c * 10, fill: "#a855f7" },
      { name: "Communication", value: comm, fill: "#3b82f6" },
      { name: "Technical", value: tech, fill: "#ec4899" },
    ]);
  };

  const saveResult = async () => {
    if (!result || score === null) return;
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { error } = await supabase.from("predictions").insert({
      user_id: user.id,
      type: "placement",
      inputs: {
        cgpa: parseFloat(cgpa) || 0,
        communication: parseFloat(communication) || 0,
        technical: parseFloat(technical) || 0,
      },
      result,
      score,
    } as any);

    if (error) toast.error("Failed to save");
    else {
      toast.success("Prediction saved!");
      loadHistory();
    }
  };

  const deleteRecord = async (id: string) => {
    await supabase.from("predictions").delete().eq("id", id);
    toast.success("Deleted");
    loadHistory();
  };

  const isValid = cgpa && communication && technical;

  const gaugeData = score !== null ? [
    { name: "Score", value: Math.min(score, 100), fill: chanceColors[result!] },
  ] : [];

  const comparisonData = history.slice(0, 10).reverse().map((h, i) => ({
    name: `#${i + 1}`,
    Score: h.score,
    CGPA: h.inputs.cgpa * 10,
    Communication: h.inputs.communication,
    Technical: h.inputs.technical,
  }));

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl gradient-warm flex items-center justify-center" style={{ boxShadow: "0 0 20px hsl(330, 90%, 60%, 0.3)" }}>
            <Briefcase size={24} className="text-primary-foreground" />
          </div>
          <div>
            <h2 className="text-3xl lg:text-4xl font-bold font-display gradient-text">
              Placement Prediction
            </h2>
            <p className="text-muted-foreground text-sm mt-1">Estimate your placement probability</p>
          </div>
        </div>
        <button
          onClick={() => setShowHistory(!showHistory)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg border border-border text-muted-foreground hover:text-foreground hover:border-primary/50 transition-all text-sm"
        >
          <History size={16} />
          History ({history.length})
        </button>
      </div>

      {/* Form */}
      <div className="surface-elevated p-8 lg:p-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <InputBlock label="CGPA" value={cgpa} onChange={setCgpa} placeholder="0 – 10" />
          <InputBlock label="Communication %" value={communication} onChange={setCommunication} placeholder="0 – 100" />
          <InputBlock label="Technical Skills %" value={technical} onChange={setTechnical} placeholder="0 – 100" />
        </div>

        <div className="flex gap-3">
          <button
            onClick={predict}
            disabled={!isValid}
            className="group flex items-center gap-2 gradient-warm text-primary-foreground px-8 py-4 rounded-lg font-bold uppercase text-sm transition-all hover:shadow-lg hover:shadow-neon-pink/30 active:scale-95 disabled:opacity-30 disabled:cursor-not-allowed"
            style={{ boxShadow: "0 0 20px hsl(330, 90%, 60%, 0.2)" }}
          >
            Predict Placement
            <ArrowUpRight size={18} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </button>
          {result && (
            <button
              onClick={saveResult}
              className="flex items-center gap-2 border border-border px-6 py-4 rounded-lg font-bold uppercase text-sm text-muted-foreground hover:text-foreground hover:border-primary/50 transition-all"
            >
              <Save size={16} /> Save Result
            </button>
          )}
        </div>
      </div>

      {/* Results */}
      <AnimatePresence>
        {result && score !== null && (
          <motion.div
            initial={{ y: 40, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -20, opacity: 0 }}
            transition={transition}
            className="grid grid-cols-1 lg:grid-cols-3 gap-6"
          >
            <div className="surface-elevated p-6 flex flex-col items-center"
              style={{ borderLeft: `4px solid ${chanceColors[result]}` }}
            >
              <span className="text-label text-muted-foreground mb-2">Placement Chance</span>
              <span className="text-4xl font-bold font-display mb-2" style={{ color: chanceColors[result] }}>
                {result}
              </span>
              <ResponsiveContainer width="100%" height={180}>
                <RadialBarChart cx="50%" cy="50%" innerRadius="60%" outerRadius="90%" data={gaugeData} startAngle={180} endAngle={0}>
                  <RadialBar background={{ fill: "hsl(240, 15%, 14%)" }} dataKey="value" cornerRadius={10} />
                </RadialBarChart>
              </ResponsiveContainer>
              <span className="text-3xl font-bold font-display gradient-text -mt-8">{score.toFixed(1)}%</span>
            </div>

            <div className="surface-elevated p-6">
              <span className="text-label text-muted-foreground block mb-4">Score Distribution</span>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie data={chartData} cx="50%" cy="50%" innerRadius={60} outerRadius={90} paddingAngle={5} dataKey="value">
                    {chartData.map((entry, index) => (
                      <Cell key={index} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ backgroundColor: "hsl(240, 18%, 8%)", border: "1px solid hsl(240, 15%, 18%)", borderRadius: "8px", color: "#fff" }} />
                  <Legend wrapperStyle={{ color: "hsl(240, 10%, 55%)" }} />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="surface-elevated p-6">
              <span className="text-label text-muted-foreground block mb-4">Skill Comparison</span>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={chartData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(240, 15%, 18%)" />
                  <XAxis type="number" domain={[0, 100]} tick={{ fill: "hsl(240, 10%, 55%)", fontSize: 12 }} />
                  <YAxis type="category" dataKey="name" tick={{ fill: "hsl(240, 10%, 55%)", fontSize: 12 }} width={100} />
                  <Tooltip contentStyle={{ backgroundColor: "hsl(240, 18%, 8%)", border: "1px solid hsl(240, 15%, 18%)", borderRadius: "8px", color: "#fff" }} />
                  <Bar dataKey="value" radius={[0, 6, 6, 0]}>
                    {chartData.map((entry, index) => (
                      <Cell key={index} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
              <p className="text-sm text-muted-foreground mt-4">{chanceText[result]}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* History & Comparison */}
      <AnimatePresence>
        {showHistory && (
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -20, opacity: 0 }}
            transition={transition}
            className="space-y-6"
          >
            {history.length >= 2 && (
              <div className="surface-elevated p-6">
                <span className="text-label text-muted-foreground block mb-4">Placement Comparison (Last 10)</span>
                <ResponsiveContainer width="100%" height={280}>
                  <LineChart data={comparisonData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(240, 15%, 18%)" />
                    <XAxis dataKey="name" tick={{ fill: "hsl(240, 10%, 55%)", fontSize: 12 }} />
                    <YAxis domain={[0, 100]} tick={{ fill: "hsl(240, 10%, 55%)", fontSize: 12 }} />
                    <Tooltip contentStyle={{ backgroundColor: "hsl(240, 18%, 8%)", border: "1px solid hsl(240, 15%, 18%)", borderRadius: "8px", color: "#fff" }} />
                    <Legend wrapperStyle={{ color: "hsl(240, 10%, 55%)" }} />
                    <Line type="monotone" dataKey="Score" stroke="#a855f7" strokeWidth={2} dot={{ r: 4 }} />
                    <Line type="monotone" dataKey="CGPA" stroke="#3b82f6" strokeWidth={2} dot={{ r: 4 }} />
                    <Line type="monotone" dataKey="Communication" stroke="#22d3a0" strokeWidth={2} dot={{ r: 4 }} />
                    <Line type="monotone" dataKey="Technical" stroke="#ec4899" strokeWidth={2} dot={{ r: 4 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}

            <div className="surface-elevated p-6">
              <span className="text-label text-muted-foreground block mb-4">Past Predictions</span>
              {history.length === 0 ? (
                <p className="text-muted-foreground text-sm">No saved predictions yet. Make a prediction and save it!</p>
              ) : (
                <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                  {history.map((h) => (
                    <div key={h.id} className="flex items-center justify-between p-4 rounded-lg bg-secondary/50 border border-border">
                      <div className="flex items-center gap-4">
                        <span className="text-sm font-bold" style={{ color: chanceColors[h.result] || "#fff" }}>
                          {h.result}
                        </span>
                        <span className="text-lg font-bold font-display gradient-text">{h.score.toFixed(1)}%</span>
                        <span className="text-xs text-muted-foreground">
                          CGPA:{h.inputs.cgpa} | Comm:{h.inputs.communication}% | Tech:{h.inputs.technical}%
                        </span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-xs text-muted-foreground">
                          {new Date(h.created_at).toLocaleDateString()}
                        </span>
                        <button onClick={() => deleteRecord(h.id)} className="text-muted-foreground hover:text-destructive transition-colors">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const InputBlock = ({
  label, value, onChange, placeholder,
}: {
  label: string; value: string; onChange: (v: string) => void; placeholder: string;
}) => (
  <div className="flex flex-col gap-2">
    <label className="text-label text-muted-foreground">{label}</label>
    <input
      type="number"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="bg-secondary border border-border px-4 py-3 rounded-lg text-foreground font-mono text-lg focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all placeholder:text-muted-foreground/40"
    />
  </div>
);

export default PlacementPrediction;
