import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowUpRight, TrendingUp, Save, History, Trash2 } from "lucide-react";
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Cell, LineChart, Line, Legend } from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const transition = { duration: 0.8, ease: [0.19, 1, 0.22, 1] as const };

type PerformanceLevel = "Excellent" | "Good" | "Average" | "Needs Improvement" | null;

const levelColors: Record<string, string> = {
  Excellent: "#22d3a0",
  Good: "#3b9cff",
  Average: "#f5a623",
  "Needs Improvement": "#ef4444",
};

interface PredictionRecord {
  id: string;
  inputs: { marks: number; studyHours: number; sleepHours: number; attendance: number };
  result: string;
  score: number;
  created_at: string;
}

const PerformancePrediction = () => {
  const [marks, setMarks] = useState("");
  const [studyHours, setStudyHours] = useState("");
  const [sleepHours, setSleepHours] = useState("");
  const [attendance, setAttendance] = useState("");
  const [result, setResult] = useState<PerformanceLevel>(null);
  const [average, setAverage] = useState<number | null>(null);
  const [inputData, setInputData] = useState<any[]>([]);
  const [history, setHistory] = useState<PredictionRecord[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    const { data } = await supabase
      .from("predictions")
      .select("*")
      .eq("type", "performance")
      .order("created_at", { ascending: false });
    if (data) setHistory(data as unknown as PredictionRecord[]);
  };

  const predict = () => {
    const m = Math.min(Math.max(parseFloat(marks) || 0, 0), 100);
    const sh = Math.min(Math.max(parseFloat(studyHours) || 0, 0), 24);
    const sl = Math.min(Math.max(parseFloat(sleepHours) || 0, 0), 24);
    const a = Math.min(Math.max(parseFloat(attendance) || 0, 0), 100);

    const normalizedStudy = (sh / 24) * 100;
    const normalizedSleep = (sl / 24) * 100;
    const avg = (m + normalizedStudy + normalizedSleep + a) / 4;
    setAverage(avg);

    if (avg >= 75) setResult("Excellent");
    else if (avg >= 60) setResult("Good");
    else if (avg >= 40) setResult("Average");
    else setResult("Needs Improvement");

    setInputData([
      { name: "Marks", value: m, fullMark: 100 },
      { name: "Study", value: normalizedStudy, fullMark: 100 },
      { name: "Sleep", value: normalizedSleep, fullMark: 100 },
      { name: "Attendance", value: a, fullMark: 100 },
    ]);
  };

  const saveResult = async () => {
    if (!result || average === null) return;
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { error } = await supabase.from("predictions").insert({
      user_id: user.id,
      type: "performance",
      inputs: {
        marks: parseFloat(marks) || 0,
        studyHours: parseFloat(studyHours) || 0,
        sleepHours: parseFloat(sleepHours) || 0,
        attendance: parseFloat(attendance) || 0,
      },
      result,
      score: average,
    } as any);

    if (error) toast.error("Failed to save");
    else {
      toast.success("Prediction saved!");
      loadHistory();
    }
  };

  const deleteRecord = async (id: string) => {
    await supabase.from("predictions").delete().eq("id", id);
    toast.success("Deleted");
    loadHistory();
  };

  const isValid = marks && studyHours && sleepHours && attendance;

  // Build comparison chart data from history
  const comparisonData = history.slice(0, 10).reverse().map((h, i) => ({
    name: `#${i + 1}`,
    Score: h.score,
    Marks: h.inputs.marks,
    Attendance: h.inputs.attendance,
  }));

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center glow-primary">
            <TrendingUp size={24} className="text-primary-foreground" />
          </div>
          <div>
            <h2 className="text-3xl lg:text-4xl font-bold font-display gradient-text">
              Performance Prediction
            </h2>
            <p className="text-muted-foreground text-sm mt-1">Analyze your academic performance metrics</p>
          </div>
        </div>
        <button
          onClick={() => setShowHistory(!showHistory)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg border border-border text-muted-foreground hover:text-foreground hover:border-primary/50 transition-all text-sm"
        >
          <History size={16} />
          History ({history.length})
        </button>
      </div>

      {/* Form */}
      <div className="surface-elevated p-8 lg:p-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <InputBlock label="Internal Marks" value={marks} onChange={setMarks} placeholder="0 – 100" />
          <InputBlock label="Study Hours / Day" value={studyHours} onChange={setStudyHours} placeholder="0 – 24" />
          <InputBlock label="Sleep Hours / Day" value={sleepHours} onChange={setSleepHours} placeholder="0 – 24" />
          <InputBlock label="Attendance %" value={attendance} onChange={setAttendance} placeholder="0 – 100" />
        </div>

        <div className="flex gap-3">
          <button
            onClick={predict}
            disabled={!isValid}
            className="group flex items-center gap-2 gradient-primary text-primary-foreground px-8 py-4 rounded-lg font-bold uppercase text-sm transition-all hover:shadow-lg hover:shadow-primary/30 active:scale-95 disabled:opacity-30 disabled:cursor-not-allowed glow-primary"
          >
            Predict Performance
            <ArrowUpRight size={18} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </button>
          {result && (
            <button
              onClick={saveResult}
              className="flex items-center gap-2 border border-border px-6 py-4 rounded-lg font-bold uppercase text-sm text-muted-foreground hover:text-foreground hover:border-primary/50 transition-all"
            >
              <Save size={16} /> Save Result
            </button>
          )}
        </div>
      </div>

      {/* Results with Charts */}
      <AnimatePresence>
        {result && average !== null && (
          <motion.div
            initial={{ y: 40, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -20, opacity: 0 }}
            transition={transition}
            className="grid grid-cols-1 lg:grid-cols-3 gap-6"
          >
            <div className="surface-elevated p-8 flex flex-col items-center justify-center text-center"
              style={{ borderLeft: `4px solid ${levelColors[result]}` }}
            >
              <span className="text-label text-muted-foreground mb-3">Performance Level</span>
              <span className="text-4xl lg:text-5xl font-bold font-display" style={{ color: levelColors[result] }}>
                {result}
              </span>
              <span className="text-6xl font-bold font-display mt-4 gradient-text">{average.toFixed(1)}%</span>
            </div>

            <div className="surface-elevated p-6">
              <span className="text-label text-muted-foreground block mb-4">Metric Distribution</span>
              <ResponsiveContainer width="100%" height={250}>
                <RadarChart data={inputData}>
                  <PolarGrid stroke="hsl(240, 15%, 25%)" />
                  <PolarAngleAxis dataKey="name" tick={{ fill: "hsl(240, 10%, 55%)", fontSize: 12 }} />
                  <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: "hsl(240, 10%, 55%)", fontSize: 10 }} />
                  <Radar name="Score" dataKey="value" stroke={levelColors[result]} fill={levelColors[result]} fillOpacity={0.3} strokeWidth={2} />
                </RadarChart>
              </ResponsiveContainer>
            </div>

            <div className="surface-elevated p-6">
              <span className="text-label text-muted-foreground block mb-4">Score Breakdown</span>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={inputData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(240, 15%, 18%)" />
                  <XAxis dataKey="name" tick={{ fill: "hsl(240, 10%, 55%)", fontSize: 12 }} />
                  <YAxis domain={[0, 100]} tick={{ fill: "hsl(240, 10%, 55%)", fontSize: 12 }} />
                  <Tooltip contentStyle={{ backgroundColor: "hsl(240, 18%, 8%)", border: "1px solid hsl(240, 15%, 18%)", borderRadius: "8px", color: "#fff" }} />
                  <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                    {inputData.map((_, index) => (
                      <Cell key={index} fill={["#a855f7", "#3b82f6", "#ec4899", "#22d3a0"][index]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* History & Comparison */}
      <AnimatePresence>
        {showHistory && (
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -20, opacity: 0 }}
            transition={transition}
            className="space-y-6"
          >
            {/* Comparison Chart */}
            {history.length >= 2 && (
              <div className="surface-elevated p-6">
                <span className="text-label text-muted-foreground block mb-4">Performance Comparison (Last 10)</span>
                <ResponsiveContainer width="100%" height={280}>
                  <LineChart data={comparisonData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(240, 15%, 18%)" />
                    <XAxis dataKey="name" tick={{ fill: "hsl(240, 10%, 55%)", fontSize: 12 }} />
                    <YAxis domain={[0, 100]} tick={{ fill: "hsl(240, 10%, 55%)", fontSize: 12 }} />
                    <Tooltip contentStyle={{ backgroundColor: "hsl(240, 18%, 8%)", border: "1px solid hsl(240, 15%, 18%)", borderRadius: "8px", color: "#fff" }} />
                    <Legend wrapperStyle={{ color: "hsl(240, 10%, 55%)" }} />
                    <Line type="monotone" dataKey="Score" stroke="#a855f7" strokeWidth={2} dot={{ r: 4 }} />
                    <Line type="monotone" dataKey="Marks" stroke="#3b82f6" strokeWidth={2} dot={{ r: 4 }} />
                    <Line type="monotone" dataKey="Attendance" stroke="#22d3a0" strokeWidth={2} dot={{ r: 4 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}

            {/* History List */}
            <div className="surface-elevated p-6">
              <span className="text-label text-muted-foreground block mb-4">Past Predictions</span>
              {history.length === 0 ? (
                <p className="text-muted-foreground text-sm">No saved predictions yet. Make a prediction and save it!</p>
              ) : (
                <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                  {history.map((h) => (
                    <div key={h.id} className="flex items-center justify-between p-4 rounded-lg bg-secondary/50 border border-border">
                      <div className="flex items-center gap-4">
                        <span className="text-sm font-bold" style={{ color: levelColors[h.result] || "#fff" }}>
                          {h.result}
                        </span>
                        <span className="text-lg font-bold font-display gradient-text">{h.score.toFixed(1)}%</span>
                        <span className="text-xs text-muted-foreground">
                          M:{h.inputs.marks} | S:{h.inputs.studyHours}h | Sl:{h.inputs.sleepHours}h | A:{h.inputs.attendance}%
                        </span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-xs text-muted-foreground">
                          {new Date(h.created_at).toLocaleDateString()}
                        </span>
                        <button onClick={() => deleteRecord(h.id)} className="text-muted-foreground hover:text-destructive transition-colors">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const InputBlock = ({
  label, value, onChange, placeholder,
}: {
  label: string; value: string; onChange: (v: string) => void; placeholder: string;
}) => (
  <div className="flex flex-col gap-2">
    <label className="text-label text-muted-foreground">{label}</label>
    <input
      type="number"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="bg-secondary border border-border px-4 py-3 rounded-lg text-foreground font-mono text-lg focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all placeholder:text-muted-foreground/40"
    />
  </div>
);

export default PerformancePrediction;
