import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { TrendingUp, Briefcase, Target, Award, BookOpen, GraduationCap, Sparkles, ArrowRight, Zap, Trophy } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, LineChart, Line, PieChart, Pie, Cell } from "recharts";
import Navbar from "@/components/Navbar";
import AiAssistant from "@/components/AiAssistant";

const transition = { duration: 0.6, ease: [0.19, 1, 0.22, 1] as const };

const Dashboard = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [perfHistory, setPerfHistory] = useState<any[]>([]);
  const [placeHistory, setPlaceHistory] = useState<any[]>([]);
  const [goals, setGoals] = useState<any[]>([]);
  const [testResults, setTestResults] = useState<any[]>([]);
  const [profile, setProfile] = useState<any>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) navigate("/login");
      else {
        setUser(session.user);
        loadData(session.user.id);
      }
    });
  }, [navigate]);

  const loadData = async (userId: string) => {
    const [perf, place, goalsData, tests, prof] = await Promise.all([
      supabase.from("predictions").select("*").eq("type", "performance").eq("user_id", userId).order("created_at", { ascending: false }).limit(20),
      supabase.from("predictions").select("*").eq("type", "placement").eq("user_id", userId).order("created_at", { ascending: false }).limit(20),
      supabase.from("goals").select("*").eq("user_id", userId).order("created_at", { ascending: false }),
      supabase.from("mock_test_results").select("*").eq("user_id", userId).order("created_at", { ascending: false }).limit(10),
      supabase.from("profiles").select("*").eq("user_id", userId).maybeSingle(),
    ]);
    if (perf.data) setPerfHistory(perf.data);
    if (place.data) setPlaceHistory(place.data);
    if (goalsData.data) setGoals(goalsData.data);
    if (tests.data) setTestResults(tests.data);
    if (prof.data) setProfile(prof.data);
  };

  const latestPerf = perfHistory[0];
  const latestPlace = placeHistory[0];
  const avgPerfScore = perfHistory.length ? perfHistory.reduce((s, p) => s + p.score, 0) / perfHistory.length : 0;
  const avgPlaceScore = placeHistory.length ? placeHistory.reduce((s, p) => s + p.score, 0) / placeHistory.length : 0;

  // Strengths/Weaknesses from latest performance
  const getStrengthsWeaknesses = () => {
    if (!latestPerf) return { strengths: [], weaknesses: [] };
    const inputs = latestPerf.inputs as any;
    const metrics = [
      { name: "Marks", value: inputs.marks },
      { name: "Study Hours", value: (inputs.studyHours / 24) * 100 },
      { name: "Sleep", value: (inputs.sleepHours / 24) * 100 },
      { name: "Attendance", value: inputs.attendance },
    ];
    const sorted = [...metrics].sort((a, b) => b.value - a.value);
    return {
      strengths: sorted.filter(m => m.value >= 60),
      weaknesses: sorted.filter(m => m.value < 60),
    };
  };

  const { strengths, weaknesses } = getStrengthsWeaknesses();

  // Performance trend data
  const trendData = perfHistory.slice(0, 10).reverse().map((h, i) => ({
    name: new Date(h.created_at).toLocaleDateString("en", { month: "short", day: "numeric" }),
    Score: Number(h.score.toFixed(1)),
  }));

  // Achievements
  const badges = [];
  if (perfHistory.length >= 5) badges.push({ icon: "🏆", label: "Consistent Learner", desc: "5+ predictions saved" });
  if (latestPerf?.score >= 75) badges.push({ icon: "⭐", label: "Top Performer", desc: "Scored 75%+ in performance" });
  if (latestPlace?.score >= 75) badges.push({ icon: "💼", label: "Placement Ready", desc: "75%+ placement probability" });
  if (testResults.length >= 3) badges.push({ icon: "🧪", label: "Quiz Master", desc: "Completed 3+ mock tests" });
  if (goals.length >= 1) badges.push({ icon: "🎯", label: "Goal Setter", desc: "Set your first goal" });
  if (perfHistory.length >= 1 && placeHistory.length >= 1) badges.push({ icon: "📊", label: "All-Rounder", desc: "Used both predictors" });
  if (badges.length === 0) badges.push({ icon: "🌱", label: "Getting Started", desc: "Make your first prediction!" });

  const quickActions = [
    { label: "Performance", icon: TrendingUp, path: "/performance", color: "from-[hsl(265,90%,60%)] to-[hsl(200,95%,55%)]" },
    { label: "Placement", icon: Briefcase, path: "/placement", color: "from-[hsl(330,90%,60%)] to-[hsl(265,90%,60%)]" },
    { label: "Study Plan", icon: BookOpen, path: "/planner", color: "from-[hsl(160,90%,50%)] to-[hsl(200,95%,55%)]" },
    { label: "Mock Test", icon: GraduationCap, path: "/mock-test", color: "from-[hsl(45,100%,55%)] to-[hsl(330,90%,60%)]" },
    { label: "Set Goals", icon: Target, path: "/goals", color: "from-[hsl(200,95%,55%)] to-[hsl(265,90%,60%)]" },
    { label: "Profile", icon: Award, path: "/profile", color: "from-[hsl(265,90%,60%)] to-[hsl(330,90%,60%)]" },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <main className="max-w-[1400px] mx-auto px-4 pt-24 md:pt-20 pb-24 space-y-6">
        {/* Welcome */}
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={transition}>
          <div className="flex items-center gap-3 mb-1">
            <Sparkles size={20} className="text-primary" />
            <h1 className="text-2xl lg:text-3xl font-bold font-display">
              Welcome back, <span className="gradient-text">{profile?.name || user?.email?.split("@")[0] || "Student"}</span>
            </h1>
          </div>
          <p className="text-muted-foreground text-sm">Here's your academic overview at a glance.</p>
        </motion.div>

        {/* Stat Cards */}
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...transition, delay: 0.1 }}
          className="grid grid-cols-2 lg:grid-cols-4 gap-4"
        >
          <StatCard label="Avg Performance" value={`${avgPerfScore.toFixed(1)}%`} icon={<TrendingUp size={18} />} color="text-neon-purple" />
          <StatCard label="Avg Placement" value={`${avgPlaceScore.toFixed(1)}%`} icon={<Briefcase size={18} />} color="text-neon-pink" />
          <StatCard label="Tests Taken" value={testResults.length.toString()} icon={<GraduationCap size={18} />} color="text-neon-blue" />
          <StatCard label="Goals Set" value={goals.length.toString()} icon={<Target size={18} />} color="text-neon-green" />
        </motion.div>

        {/* Quick Actions */}
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...transition, delay: 0.15 }}
          className="grid grid-cols-3 lg:grid-cols-6 gap-3"
        >
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <button
                key={action.path}
                onClick={() => navigate(action.path)}
                className="group surface-elevated p-4 flex flex-col items-center gap-2 hover:border-primary/40 transition-all"
              >
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${action.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                  <Icon size={18} className="text-white" />
                </div>
                <span className="text-xs font-medium text-muted-foreground group-hover:text-foreground transition-colors">{action.label}</span>
              </button>
            );
          })}
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Performance Trend */}
          <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...transition, delay: 0.2 }}
            className="lg:col-span-2 surface-elevated p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <span className="text-label text-muted-foreground">📈 Performance Trend</span>
              <button onClick={() => navigate("/performance")} className="text-xs text-primary flex items-center gap-1 hover:underline">
                View All <ArrowRight size={12} />
              </button>
            </div>
            {trendData.length >= 2 ? (
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(240, 15%, 18%)" />
                  <XAxis dataKey="name" tick={{ fill: "hsl(240, 10%, 55%)", fontSize: 11 }} />
                  <YAxis domain={[0, 100]} tick={{ fill: "hsl(240, 10%, 55%)", fontSize: 11 }} />
                  <Tooltip contentStyle={{ backgroundColor: "hsl(240, 18%, 8%)", border: "1px solid hsl(240, 15%, 18%)", borderRadius: "8px", color: "#fff" }} />
                  <Line type="monotone" dataKey="Score" stroke="#a855f7" strokeWidth={2} dot={{ r: 4, fill: "#a855f7" }} />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[220px] flex items-center justify-center text-muted-foreground text-sm">
                Save 2+ performance predictions to see your trend chart
              </div>
            )}
          </motion.div>

          {/* Strengths & Weaknesses */}
          <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...transition, delay: 0.25 }}
            className="surface-elevated p-6"
          >
            <span className="text-label text-muted-foreground block mb-4">🎯 Strengths vs Weaknesses</span>
            {latestPerf ? (
              <div className="space-y-4">
                {strengths.length > 0 && (
                  <div>
                    <span className="text-xs font-semibold text-neon-green mb-2 block">💪 Strengths</span>
                    {strengths.map((s) => (
                      <div key={s.name} className="flex items-center justify-between py-1.5">
                        <span className="text-sm text-foreground">{s.name}</span>
                        <div className="flex items-center gap-2">
                          <div className="w-20 h-2 rounded-full bg-secondary overflow-hidden">
                            <div className="h-full rounded-full bg-neon-green" style={{ width: `${s.value}%` }} />
                          </div>
                          <span className="text-xs text-muted-foreground w-8">{s.value.toFixed(0)}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                {weaknesses.length > 0 && (
                  <div>
                    <span className="text-xs font-semibold text-destructive mb-2 block">⚠️ Needs Work</span>
                    {weaknesses.map((w) => (
                      <div key={w.name} className="flex items-center justify-between py-1.5">
                        <span className="text-sm text-foreground">{w.name}</span>
                        <div className="flex items-center gap-2">
                          <div className="w-20 h-2 rounded-full bg-secondary overflow-hidden">
                            <div className="h-full rounded-full bg-destructive" style={{ width: `${w.value}%` }} />
                          </div>
                          <span className="text-xs text-muted-foreground w-8">{w.value.toFixed(0)}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="h-40 flex items-center justify-center text-muted-foreground text-sm text-center">
                Make a performance prediction to see your strengths & weaknesses
              </div>
            )}
          </motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Achievements */}
          <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...transition, delay: 0.3 }}
            className="surface-elevated p-6"
          >
            <div className="flex items-center gap-2 mb-4">
              <Trophy size={16} className="text-warning" />
              <span className="text-label text-muted-foreground">🏆 Achievements</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {badges.map((badge, i) => (
                <div key={i} className="p-3 rounded-lg bg-secondary/50 border border-border flex items-center gap-3">
                  <span className="text-2xl">{badge.icon}</span>
                  <div>
                    <span className="text-sm font-bold text-foreground block">{badge.label}</span>
                    <span className="text-[10px] text-muted-foreground">{badge.desc}</span>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Recent Activity */}
          <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...transition, delay: 0.35 }}
            className="surface-elevated p-6"
          >
            <span className="text-label text-muted-foreground block mb-4">⚡ Recent Activity</span>
            <div className="space-y-3 max-h-[250px] overflow-y-auto">
              {[...perfHistory.slice(0, 3).map(h => ({ ...h, _type: "perf" })), ...placeHistory.slice(0, 3).map(h => ({ ...h, _type: "place" }))]
                .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
                .slice(0, 5)
                .map((item: any) => (
                  <div key={item.id} className="flex items-center gap-3 p-3 rounded-lg bg-secondary/30 border border-border/50">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${item._type === "perf" ? "gradient-primary" : "gradient-warm"}`}>
                      {item._type === "perf" ? <TrendingUp size={14} className="text-white" /> : <Briefcase size={14} className="text-white" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className="text-sm font-medium text-foreground">
                        {item._type === "perf" ? "Performance" : "Placement"}: {item.result}
                      </span>
                      <span className="text-[10px] text-muted-foreground block">
                        {new Date(item.created_at).toLocaleDateString()} · Score: {Number(item.score).toFixed(1)}%
                      </span>
                    </div>
                  </div>
                ))}
              {perfHistory.length === 0 && placeHistory.length === 0 && (
                <p className="text-muted-foreground text-sm text-center py-8">No activity yet. Start by making a prediction!</p>
              )}
            </div>
          </motion.div>
        </div>
      </main>
      <AiAssistant />
    </div>
  );
};

const StatCard = ({ label, value, icon, color }: { label: string; value: string; icon: React.ReactNode; color: string }) => (
  <div className="surface-elevated p-4 flex items-center gap-3">
    <div className={`${color}`}>{icon}</div>
    <div>
      <span className="text-xl font-bold font-display text-foreground">{value}</span>
      <span className="text-[10px] text-muted-foreground block text-label">{label}</span>
    </div>
  </div>
);

export default Dashboard;
