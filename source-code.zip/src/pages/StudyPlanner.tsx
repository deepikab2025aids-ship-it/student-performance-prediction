import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { BookOpen, Sparkles, Trash2, Clock, Coffee, Plus, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import Navbar from "@/components/Navbar";
import AiAssistant from "@/components/AiAssistant";

const transition = { duration: 0.6, ease: [0.19, 1, 0.22, 1] as const };

const timeSlots = [
  { start: "6:00 AM", end: "7:00 AM" },
  { start: "7:00 AM", end: "8:00 AM" },
  { start: "8:00 AM", end: "9:00 AM" },
  { start: "9:00 AM", end: "10:00 AM" },
  { start: "10:00 AM", end: "11:00 AM" },
  { start: "11:00 AM", end: "12:00 PM" },
  { start: "2:00 PM", end: "3:00 PM" },
  { start: "3:00 PM", end: "4:00 PM" },
  { start: "4:00 PM", end: "5:00 PM" },
  { start: "6:00 PM", end: "7:00 PM" },
  { start: "7:00 PM", end: "7:30 PM", isBreak: true },
  { start: "7:30 PM", end: "8:30 PM" },
  { start: "8:30 PM", end: "9:30 PM" },
];

interface Plan {
  id: string;
  plan_data: any[];
  weak_subjects: string[];
  created_at: string;
}

const StudyPlanner = () => {
  const navigate = useNavigate();
  const [weakSubjects, setWeakSubjects] = useState<string[]>([]);
  const [newSubject, setNewSubject] = useState("");
  const [studyHours, setStudyHours] = useState(6);
  const [generatedPlan, setGeneratedPlan] = useState<any[] | null>(null);
  const [savedPlans, setSavedPlans] = useState<Plan[]>([]);
  const [user, setUser] = useState<any>(null);

  const addSubject = () => {
    const trimmed = newSubject.trim();
    if (!trimmed) return;
    if (weakSubjects.includes(trimmed)) {
      toast.error("Subject already added");
      return;
    }
    setWeakSubjects((prev) => [...prev, trimmed]);
    setNewSubject("");
  };

  const removeSubject = (subject: string) => {
    setWeakSubjects((prev) => prev.filter((s) => s !== subject));
  };

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) navigate("/login");
      else {
        setUser(session.user);
        loadPlans(session.user.id);
      }
    });
  }, [navigate]);

  const loadPlans = async (userId: string) => {
    const { data } = await supabase.from("study_plans").select("*").eq("user_id", userId).order("created_at", { ascending: false });
    if (data) setSavedPlans(data as unknown as Plan[]);
  };



  const generatePlan = () => {
    if (weakSubjects.length === 0) {
      toast.error("Select at least one weak subject");
      return;
    }

    const availableSlots = timeSlots.filter((s) => !s.isBreak);
    const slotsToUse = availableSlots.slice(0, studyHours);
    const plan: any[] = [];

    slotsToUse.forEach((slot, i) => {
      const subject = weakSubjects[i % weakSubjects.length];
      plan.push({
        time: `${slot.start} – ${slot.end}`,
        subject,
        type: "study",
      });
      // Add break after every 2 study sessions
      if ((i + 1) % 2 === 0 && i < slotsToUse.length - 1) {
        plan.push({
          time: "Break",
          subject: "Rest & Refresh ☕",
          type: "break",
        });
      }
    });

    setGeneratedPlan(plan);
    toast.success("Study plan generated!");
  };

  const savePlan = async () => {
    if (!generatedPlan || !user) return;
    const { error } = await supabase.from("study_plans").insert({
      user_id: user.id,
      plan_data: generatedPlan,
      weak_subjects: weakSubjects,
    } as any);
    if (error) toast.error("Failed to save plan");
    else {
      toast.success("Plan saved!");
      loadPlans(user.id);
    }
  };

  const deletePlan = async (id: string) => {
    await supabase.from("study_plans").delete().eq("id", id);
    toast.success("Plan deleted");
    if (user) loadPlans(user.id);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <main className="max-w-[1000px] mx-auto px-4 pt-24 md:pt-20 pb-24 space-y-6">
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={transition}>
          <div className="flex items-center gap-3 mb-1">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[hsl(160,90%,50%)] to-[hsl(200,95%,55%)] flex items-center justify-center">
              <BookOpen size={20} className="text-white" />
            </div>
            <div>
              <h1 className="text-2xl lg:text-3xl font-bold font-display gradient-text">Study Planner</h1>
              <p className="text-muted-foreground text-sm">Auto-generate a timetable based on your weak subjects</p>
            </div>
          </div>
        </motion.div>

        {/* Subject Selection */}
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...transition, delay: 0.1 }}
          className="surface-elevated p-6"
        >
          <span className="text-label text-muted-foreground block mb-3">Add Your Weak Subjects</span>
          <div className="flex gap-2 mb-4">
            <input
              type="text"
              value={newSubject}
              onChange={(e) => setNewSubject(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addSubject()}
              placeholder="Type a subject and press Enter..."
              className="flex-1 px-4 py-2 rounded-lg text-sm border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
            <button onClick={addSubject}
              className="flex items-center gap-1 px-4 py-2 rounded-lg text-sm font-medium gradient-primary text-primary-foreground"
            >
              <Plus size={14} /> Add
            </button>
          </div>
          {weakSubjects.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-6">
              {weakSubjects.map((subject) => (
                <span key={subject} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium gradient-primary text-primary-foreground border border-primary/30">
                  {subject}
                  <button onClick={() => removeSubject(subject)} className="hover:opacity-70">
                    <X size={12} />
                  </button>
                </span>
              ))}
            </div>
          )}
          {weakSubjects.length === 0 && (
            <p className="text-xs text-muted-foreground mb-6">No subjects added yet. Type your subjects above.</p>
          )}

          <div className="flex items-center gap-4 mb-6">
            <label className="text-label text-muted-foreground">Study Hours / Day</label>
            <input
              type="range" min={2} max={10} value={studyHours} onChange={(e) => setStudyHours(parseInt(e.target.value))}
              className="flex-1 accent-primary"
            />
            <span className="text-lg font-bold font-display gradient-text">{studyHours}h</span>
          </div>

          <button onClick={generatePlan}
            className="flex items-center gap-2 gradient-primary text-primary-foreground px-6 py-3 rounded-lg font-bold uppercase text-sm transition-all hover:shadow-lg hover:shadow-primary/30 active:scale-95 glow-primary"
          >
            <Sparkles size={16} /> Generate Plan
          </button>
        </motion.div>

        {/* Generated Plan */}
        {generatedPlan && (
          <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={transition}
            className="surface-elevated p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <span className="text-label text-muted-foreground">📅 Your Study Schedule</span>
              <button onClick={savePlan}
                className="text-xs px-3 py-1.5 rounded-lg gradient-primary text-primary-foreground font-bold uppercase"
              >
                Save Plan
              </button>
            </div>
            <div className="space-y-2">
              {generatedPlan.map((slot, i) => (
                <div key={i} className={`flex items-center gap-4 p-3 rounded-lg border ${
                  slot.type === "break"
                    ? "bg-warning/5 border-warning/20"
                    : "bg-secondary/50 border-border"
                }`}>
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                    slot.type === "break" ? "bg-warning/20" : "gradient-primary"
                  }`}>
                    {slot.type === "break" ? <Coffee size={14} className="text-warning" /> : <Clock size={14} className="text-white" />}
                  </div>
                  <span className="text-sm font-mono text-muted-foreground w-36">{slot.time}</span>
                  <span className={`text-sm font-medium ${slot.type === "break" ? "text-warning" : "text-foreground"}`}>{slot.subject}</span>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Saved Plans */}
        {savedPlans.length > 0 && (
          <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...transition, delay: 0.15 }}
            className="surface-elevated p-6"
          >
            <span className="text-label text-muted-foreground block mb-4">📚 Saved Plans</span>
            <div className="space-y-3">
              {savedPlans.map((plan) => (
                <div key={plan.id} className="p-4 rounded-lg bg-secondary/50 border border-border">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <span className="text-sm font-medium text-foreground">Plan from {new Date(plan.created_at).toLocaleDateString()}</span>
                      <span className="text-xs text-muted-foreground block">
                        Subjects: {(plan.weak_subjects as string[]).join(", ")}
                      </span>
                    </div>
                    <button onClick={() => deletePlan(plan.id)} className="text-muted-foreground hover:text-destructive transition-colors">
                      <Trash2 size={14} />
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {(plan.plan_data as any[]).filter(s => s.type !== "break").map((slot, i) => (
                      <span key={i} className="text-[10px] px-2 py-1 rounded bg-primary/10 text-primary border border-primary/20">
                        {slot.time}: {slot.subject}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </main>
      <AiAssistant />
    </div>
  );
};

export default StudyPlanner;
