import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Settings as SettingsIcon, Lock, Mail, Bell, BellOff, Shield, Eye, EyeOff } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import Navbar from "@/components/Navbar";

const transition = { duration: 0.6, ease: [0.19, 1, 0.22, 1] as const };

const Settings = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);

  // Password
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [changingPassword, setChangingPassword] = useState(false);

  // Email
  const [newEmail, setNewEmail] = useState("");
  const [changingEmail, setChangingEmail] = useState(false);

  // Notifications
  const [notifications, setNotifications] = useState({
    emailUpdates: true,
    performanceAlerts: true,
    studyReminders: true,
    mockTestResults: true,
    goalDeadlines: true,
  });

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) navigate("/login");
      else setUser(session.user);
    });
  }, [navigate]);

  const handleChangePassword = async () => {
    if (!newPassword || !confirmPassword) {
      toast.error("Please fill in all password fields");
      return;
    }
    if (newPassword.length < 6) {
      toast.error("Password must be at least 6 characters");
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }

    setChangingPassword(true);
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    setChangingPassword(false);

    if (error) {
      toast.error(error.message);
    } else {
      toast.success("Password updated successfully!");
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    }
  };

  const handleChangeEmail = async () => {
    if (!newEmail) {
      toast.error("Please enter a new email");
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(newEmail)) {
      toast.error("Please enter a valid email address");
      return;
    }

    setChangingEmail(true);
    const { error } = await supabase.auth.updateUser({ email: newEmail });
    setChangingEmail(false);

    if (error) {
      toast.error(error.message);
    } else {
      toast.success("Verification email sent to your new address!");
      setNewEmail("");
    }
  };

  const toggleNotification = (key: keyof typeof notifications) => {
    setNotifications((prev) => ({ ...prev, [key]: !prev[key] }));
    toast.success(`Notification ${notifications[key] ? "disabled" : "enabled"}`);
  };

  const notificationItems = [
    { key: "emailUpdates" as const, label: "Email Updates", desc: "Receive general updates and announcements" },
    { key: "performanceAlerts" as const, label: "Performance Alerts", desc: "Get notified about significant score changes" },
    { key: "studyReminders" as const, label: "Study Reminders", desc: "Daily reminders to follow your study plan" },
    { key: "mockTestResults" as const, label: "Mock Test Results", desc: "Notifications when test results are ready" },
    { key: "goalDeadlines" as const, label: "Goal Deadlines", desc: "Alerts when your goal deadlines are approaching" },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <main className="max-w-[800px] mx-auto px-4 pt-24 md:pt-20 pb-24 space-y-6">
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={transition}>
          <div className="flex items-center gap-3 mb-1">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[hsl(250,90%,60%)] to-[hsl(280,95%,55%)] flex items-center justify-center">
              <SettingsIcon size={20} className="text-white" />
            </div>
            <div>
              <h1 className="text-2xl lg:text-3xl font-bold font-display gradient-text">Settings</h1>
              <p className="text-muted-foreground text-sm">Manage your account, security & notifications</p>
            </div>
          </div>
        </motion.div>

        {/* Change Password */}
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...transition, delay: 0.1 }}
          className="surface-elevated p-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <Lock size={18} className="text-primary" />
            <span className="text-label text-foreground font-bold">Change Password</span>
          </div>
          <div className="space-y-3 max-w-md">
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="New password"
                className="w-full px-4 py-2.5 rounded-lg text-sm border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40"
              />
              <button onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
            <input
              type={showPassword ? "text" : "password"}
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Confirm new password"
              className="w-full px-4 py-2.5 rounded-lg text-sm border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
            <button onClick={handleChangePassword} disabled={changingPassword}
              className="gradient-primary text-primary-foreground px-6 py-2.5 rounded-lg font-bold uppercase text-sm transition-all hover:shadow-lg hover:shadow-primary/30 active:scale-95 disabled:opacity-50 glow-primary"
            >
              {changingPassword ? "Updating..." : "Update Password"}
            </button>
          </div>
        </motion.div>

        {/* Change Email */}
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...transition, delay: 0.15 }}
          className="surface-elevated p-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <Mail size={18} className="text-primary" />
            <span className="text-label text-foreground font-bold">Change Email</span>
          </div>
          <p className="text-xs text-muted-foreground mb-3">
            Current email: <span className="text-foreground">{user?.email}</span>
          </p>
          <div className="space-y-3 max-w-md">
            <input
              type="email"
              value={newEmail}
              onChange={(e) => setNewEmail(e.target.value)}
              placeholder="New email address"
              className="w-full px-4 py-2.5 rounded-lg text-sm border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
            <button onClick={handleChangeEmail} disabled={changingEmail}
              className="gradient-primary text-primary-foreground px-6 py-2.5 rounded-lg font-bold uppercase text-sm transition-all hover:shadow-lg hover:shadow-primary/30 active:scale-95 disabled:opacity-50 glow-primary"
            >
              {changingEmail ? "Sending..." : "Update Email"}
            </button>
          </div>
        </motion.div>

        {/* Notifications */}
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...transition, delay: 0.2 }}
          className="surface-elevated p-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <Bell size={18} className="text-primary" />
            <span className="text-label text-foreground font-bold">Notifications</span>
          </div>
          <div className="space-y-3">
            {notificationItems.map((item) => (
              <div key={item.key} className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 border border-border">
                <div>
                  <span className="text-sm font-medium text-foreground">{item.label}</span>
                  <span className="text-xs text-muted-foreground block">{item.desc}</span>
                </div>
                <button
                  onClick={() => toggleNotification(item.key)}
                  className={`relative w-11 h-6 rounded-full transition-colors ${
                    notifications[item.key] ? "bg-primary" : "bg-muted"
                  }`}
                >
                  <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${
                    notifications[item.key] ? "left-[22px]" : "left-0.5"
                  }`} />
                </button>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Account Info */}
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...transition, delay: 0.25 }}
          className="surface-elevated p-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <Shield size={18} className="text-primary" />
            <span className="text-label text-foreground font-bold">Account Info</span>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between p-3 rounded-lg bg-secondary/50 border border-border">
              <span className="text-muted-foreground">Account ID</span>
              <span className="text-foreground font-mono text-xs">{user?.id?.slice(0, 8)}...</span>
            </div>
            <div className="flex justify-between p-3 rounded-lg bg-secondary/50 border border-border">
              <span className="text-muted-foreground">Joined</span>
              <span className="text-foreground">{user?.created_at ? new Date(user.created_at).toLocaleDateString() : "—"}</span>
            </div>
            <div className="flex justify-between p-3 rounded-lg bg-secondary/50 border border-border">
              <span className="text-muted-foreground">Last Sign In</span>
              <span className="text-foreground">{user?.last_sign_in_at ? new Date(user.last_sign_in_at).toLocaleDateString() : "—"}</span>
            </div>
          </div>
        </motion.div>
      </main>
    </div>
  );
};

export default Settings;
