import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { User, Save, Mail, Building2, Calendar, Download } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Cell } from "recharts";
import Navbar from "@/components/Navbar";
import AiAssistant from "@/components/AiAssistant";

const transition = { duration: 0.6, ease: [0.19, 1, 0.22, 1] as const };

const Profile = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState({ name: "", department: "", year: 1 });
  const [perfHistory, setPerfHistory] = useState<any[]>([]);
  const [placeHistory, setPlaceHistory] = useState<any[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) navigate("/login");
      else {
        setUser(session.user);
        loadData(session.user.id);
      }
    });
  }, [navigate]);

  const loadData = async (userId: string) => {
    const [prof, perf, place] = await Promise.all([
      supabase.from("profiles").select("*").eq("user_id", userId).maybeSingle(),
      supabase.from("predictions").select("*").eq("type", "performance").eq("user_id", userId).order("created_at", { ascending: false }),
      supabase.from("predictions").select("*").eq("type", "placement").eq("user_id", userId).order("created_at", { ascending: false }),
    ]);
    if (prof.data) setProfile({ name: prof.data.name, department: prof.data.department, year: prof.data.year });
    if (perf.data) setPerfHistory(perf.data);
    if (place.data) setPlaceHistory(place.data);
  };

  const saveProfile = async () => {
    if (!user) return;
    setSaving(true);
    const { error } = await supabase.from("profiles").upsert({
      user_id: user.id,
      ...profile,
      updated_at: new Date().toISOString(),
    } as any, { onConflict: "user_id" });
    if (error) toast.error("Failed to save profile");
    else toast.success("Profile updated!");
    setSaving(false);
  };

  const generatePDFReport = () => {
    const content = [];
    content.push("═══════════════════════════════════════");
    content.push("       STUDENT PREDICTION REPORT       ");
    content.push("═══════════════════════════════════════");
    content.push(`\nStudent: ${profile.name || "N/A"}`);
    content.push(`Email: ${user?.email || "N/A"}`);
    content.push(`Department: ${profile.department || "N/A"}`);
    content.push(`Year: ${profile.year}`);
    content.push(`Generated: ${new Date().toLocaleDateString()}\n`);

    content.push("───── PERFORMANCE HISTORY ─────");
    if (perfHistory.length === 0) content.push("No records yet.");
    perfHistory.forEach((h, i) => {
      const inp = h.inputs as any;
      content.push(`\n${i + 1}. ${h.result} (${Number(h.score).toFixed(1)}%) - ${new Date(h.created_at).toLocaleDateString()}`);
      content.push(`   Marks: ${inp.marks} | Study: ${inp.studyHours}h | Sleep: ${inp.sleepHours}h | Attendance: ${inp.attendance}%`);
    });

    content.push("\n\n───── PLACEMENT HISTORY ─────");
    if (placeHistory.length === 0) content.push("No records yet.");
    placeHistory.forEach((h, i) => {
      const inp = h.inputs as any;
      content.push(`\n${i + 1}. ${h.result} (${Number(h.score).toFixed(1)}%) - ${new Date(h.created_at).toLocaleDateString()}`);
      content.push(`   CGPA: ${inp.cgpa} | Communication: ${inp.communication}% | Technical: ${inp.technical}%`);
    });

    content.push("\n\n═══════════════════════════════════════");
    content.push("         End of Report");
    content.push("═══════════════════════════════════════");

    const blob = new Blob([content.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `student-report-${new Date().toISOString().split("T")[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Report downloaded!");
  };

  const summaryData = [
    { name: "Performance", count: perfHistory.length, fill: "#a855f7" },
    { name: "Placement", count: placeHistory.length, fill: "#ec4899" },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <main className="max-w-[900px] mx-auto px-4 pt-24 md:pt-20 pb-24 space-y-6">
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={transition}>
          <h1 className="text-3xl font-bold font-display gradient-text mb-1">Student Profile</h1>
          <p className="text-muted-foreground text-sm">Manage your information and view prediction history</p>
        </motion.div>

        {/* Profile Form */}
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...transition, delay: 0.1 }}
          className="surface-elevated p-6 lg:p-8"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center">
              <User size={22} className="text-white" />
            </div>
            <div>
              <h2 className="font-bold font-display text-lg">Personal Information</h2>
              <span className="text-xs text-muted-foreground">{user?.email}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="flex flex-col gap-2">
              <label className="text-label text-muted-foreground flex items-center gap-1"><User size={12} /> Full Name</label>
              <input
                type="text" value={profile.name} onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                placeholder="Your name" className="bg-secondary border border-border px-4 py-3 rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all placeholder:text-muted-foreground/40"
              />
            </div>
            <div className="flex flex-col gap-2">
              <label className="text-label text-muted-foreground flex items-center gap-1"><Building2 size={12} /> Department</label>
              <input
                type="text" value={profile.department} onChange={(e) => setProfile({ ...profile, department: e.target.value })}
                placeholder="e.g. Computer Science" className="bg-secondary border border-border px-4 py-3 rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all placeholder:text-muted-foreground/40"
              />
            </div>
            <div className="flex flex-col gap-2">
              <label className="text-label text-muted-foreground flex items-center gap-1"><Calendar size={12} /> Year</label>
              <select
                value={profile.year} onChange={(e) => setProfile({ ...profile, year: parseInt(e.target.value) })}
                className="bg-secondary border border-border px-4 py-3 rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all"
              >
                {[1, 2, 3, 4].map(y => <option key={y} value={y}>Year {y}</option>)}
              </select>
            </div>
          </div>

          <div className="flex gap-3">
            <button onClick={saveProfile} disabled={saving}
              className="flex items-center gap-2 gradient-primary text-primary-foreground px-6 py-3 rounded-lg font-bold uppercase text-sm transition-all hover:shadow-lg hover:shadow-primary/30 active:scale-95 disabled:opacity-50 glow-primary"
            >
              <Save size={16} /> {saving ? "Saving..." : "Save Profile"}
            </button>
            <button onClick={generatePDFReport}
              className="flex items-center gap-2 border border-border px-6 py-3 rounded-lg font-bold uppercase text-sm text-muted-foreground hover:text-foreground hover:border-primary/50 transition-all"
            >
              <Download size={16} /> Download Report
            </button>
          </div>
        </motion.div>

        {/* Prediction Summary */}
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...transition, delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
        >
          <div className="surface-elevated p-6">
            <span className="text-label text-muted-foreground block mb-4">Prediction Summary</span>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={summaryData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(240, 15%, 18%)" />
                <XAxis dataKey="name" tick={{ fill: "hsl(240, 10%, 55%)", fontSize: 12 }} />
                <YAxis tick={{ fill: "hsl(240, 10%, 55%)", fontSize: 12 }} />
                <Tooltip contentStyle={{ backgroundColor: "hsl(240, 18%, 8%)", border: "1px solid hsl(240, 15%, 18%)", borderRadius: "8px", color: "#fff" }} />
                <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                  {summaryData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="surface-elevated p-6">
            <span className="text-label text-muted-foreground block mb-4">Quick Stats</span>
            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 rounded-lg bg-secondary/50 border border-border">
                <span className="text-sm text-muted-foreground">Total Predictions</span>
                <span className="font-bold font-display gradient-text">{perfHistory.length + placeHistory.length}</span>
              </div>
              <div className="flex justify-between items-center p-3 rounded-lg bg-secondary/50 border border-border">
                <span className="text-sm text-muted-foreground">Best Performance</span>
                <span className="font-bold text-neon-green">{perfHistory.length ? `${Math.max(...perfHistory.map(h => h.score)).toFixed(1)}%` : "N/A"}</span>
              </div>
              <div className="flex justify-between items-center p-3 rounded-lg bg-secondary/50 border border-border">
                <span className="text-sm text-muted-foreground">Best Placement</span>
                <span className="font-bold text-neon-pink">{placeHistory.length ? `${Math.max(...placeHistory.map(h => h.score)).toFixed(1)}%` : "N/A"}</span>
              </div>
              <div className="flex justify-between items-center p-3 rounded-lg bg-secondary/50 border border-border">
                <span className="text-sm text-muted-foreground">Member Since</span>
                <span className="font-bold text-foreground text-sm">{user ? new Date(user.created_at).toLocaleDateString() : "N/A"}</span>
              </div>
            </div>
          </div>
        </motion.div>
      </main>
      <AiAssistant />
    </div>
  );
};

export default Profile;
