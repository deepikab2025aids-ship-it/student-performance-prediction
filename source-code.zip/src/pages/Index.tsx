import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { TrendingUp, Briefcase, Sparkles, LayoutDashboard, BookOpen, GraduationCap, Target, User } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import Navbar from "@/components/Navbar";
import AiAssistant from "@/components/AiAssistant";

const transition = { duration: 0.8, ease: [0.19, 1, 0.22, 1] as const };

const features = [
  { icon: LayoutDashboard, label: "Dashboard", desc: "Overview of all your academic metrics, trends, and achievements", path: "/dashboard", gradient: "gradient-primary" },
  { icon: TrendingUp, label: "Performance", desc: "Predict academic performance based on marks, study hours, attendance", path: "/performance", gradient: "gradient-primary" },
  { icon: Briefcase, label: "Placement", desc: "Estimate placement probability using CGPA and skills", path: "/placement", gradient: "gradient-warm" },
  { icon: BookOpen, label: "Study Planner", desc: "Auto-generate timetable based on your weak subjects", path: "/planner", gradient: "bg-gradient-to-br from-[hsl(160,90%,50%)] to-[hsl(200,95%,55%)]" },
  { icon: GraduationCap, label: "Mock Tests", desc: "Practice MCQ quizzes and track your scores", path: "/mock-test", gradient: "bg-gradient-to-br from-[hsl(45,100%,55%)] to-[hsl(330,90%,60%)]" },
  { icon: Target, label: "Goal Setting", desc: "Set target marks and track your progress", path: "/goals", gradient: "bg-gradient-to-br from-[hsl(200,95%,55%)] to-[hsl(265,90%,60%)]" },
  { icon: User, label: "Profile", desc: "Manage your info and download prediction reports", path: "/profile", gradient: "bg-gradient-to-br from-[hsl(265,90%,60%)] to-[hsl(330,90%,60%)]" },
];

const Index = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) navigate("/login");
      else setUser(session.user);
    });
    return () => subscription.unsubscribe();
  }, [navigate]);

  return (
    <div className="min-h-screen bg-background text-foreground relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/3 w-[500px] h-[500px] rounded-full bg-primary/8 blur-[150px]" />
        <div className="absolute bottom-0 right-1/3 w-[500px] h-[500px] rounded-full bg-accent/8 blur-[150px]" />
        <div className="absolute top-1/2 right-0 w-[400px] h-[400px] rounded-full bg-neon-pink/5 blur-[120px]" />
      </div>

      <Navbar />

      <main className="relative z-10 max-w-[1200px] mx-auto px-6 pt-28 md:pt-24 pb-24">
        <motion.div initial={{ y: 40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={transition} className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/20 rounded-full px-4 py-1.5 mb-6 text-sm text-primary">
            <Sparkles size={14} /> AI-Powered Student Platform
          </div>
          <h1 className="text-4xl lg:text-6xl font-bold font-display mb-6">
            Your Complete <br />
            <span className="gradient-text">Academic Toolkit</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto">
            Predict performance, plan studies, take mock tests, set goals, and get AI-powered suggestions — all in one place.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 max-w-5xl mx-auto">
          {features.map((feature, i) => {
            const Icon = feature.icon;
            return (
              <motion.button
                key={feature.path}
                initial={{ y: 40, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ ...transition, delay: 0.1 + i * 0.06 }}
                onClick={() => navigate(feature.path)}
                className="group surface-elevated p-6 text-left hover:border-primary/40 transition-all duration-300"
              >
                <div className={`w-12 h-12 rounded-xl ${feature.gradient} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <Icon size={22} className="text-white" />
                </div>
                <h3 className="text-lg font-bold font-display mb-2">{feature.label}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{feature.desc}</p>
              </motion.button>
            );
          })}
        </div>

        <motion.div initial={{ y: 40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...transition, delay: 0.6 }} className="mt-16 text-center">
          <div className="inline-flex gap-12 text-center">
            <div>
              <span className="text-3xl font-bold font-display gradient-text block">7</span>
              <span className="text-xs text-muted-foreground text-label">Features</span>
            </div>
            <div>
              <span className="text-3xl font-bold font-display gradient-text block">7</span>
              <span className="text-xs text-muted-foreground text-label">Input Metrics</span>
            </div>
            <div>
              <span className="text-3xl font-bold font-display gradient-text block">AI</span>
              <span className="text-xs text-muted-foreground text-label">Powered</span>
            </div>
          </div>
        </motion.div>
      </main>
      <AiAssistant />
    </div>
  );
};

export default Index;
