import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import PlacementPrediction from "@/components/PlacementPrediction";
import Navbar from "@/components/Navbar";
import AiAssistant from "@/components/AiAssistant";

const Placement = () => {
  const navigate = useNavigate();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) navigate("/login");
    });
  }, [navigate]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <main className="max-w-[1200px] mx-auto px-6 pt-24 md:pt-20 pb-24">
        <PlacementPrediction />
      </main>
      <AiAssistant />
    </div>
  );
};

export default Placement;
