import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import PerformancePrediction from "@/components/PerformancePrediction";
import Navbar from "@/components/Navbar";
import AiAssistant from "@/components/AiAssistant";

const Performance = () => {
  const navigate = useNavigate();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) navigate("/login");
    });
  }, [navigate]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <main className="max-w-[1200px] mx-auto px-6 pt-24 md:pt-20 pb-24">
        <PerformancePrediction />
      </main>
      <AiAssistant />
    </div>
  );
};

export default Performance;
