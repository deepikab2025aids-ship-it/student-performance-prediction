import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { GraduationCap, CheckCircle2, XCircle, Trophy, RotateCcw, Trash2, Plus, X, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import Navbar from "@/components/Navbar";
import AiAssistant from "@/components/AiAssistant";

const transition = { duration: 0.6, ease: [0.19, 1, 0.22, 1] as const };

interface Question {
  question: string;
  options: string[];
  answer: number;
}

const quizBank: Record<string, Question[]> = {
  "Data Structures": [
    { question: "What is the time complexity of binary search?", options: ["O(n)", "O(log n)", "O(n²)", "O(1)"], answer: 1 },
    { question: "Which data structure uses LIFO?", options: ["Queue", "Stack", "Array", "Linked List"], answer: 1 },
    { question: "What is the worst-case time complexity of QuickSort?", options: ["O(n log n)", "O(n)", "O(n²)", "O(log n)"], answer: 2 },
    { question: "Which traversal gives sorted output from BST?", options: ["Preorder", "Postorder", "Inorder", "Level Order"], answer: 2 },
    { question: "A complete binary tree with n nodes has height?", options: ["O(n)", "O(log n)", "O(n²)", "O(1)"], answer: 1 },
  ],
  "Programming": [
    { question: "Which keyword is used to define a class in Java?", options: ["struct", "class", "def", "object"], answer: 1 },
    { question: "What does OOP stand for?", options: ["Object Oriented Programming", "Open Order Processing", "Optimal Output Program", "None"], answer: 0 },
    { question: "Which is not a pillar of OOP?", options: ["Encapsulation", "Inheritance", "Compilation", "Polymorphism"], answer: 2 },
    { question: "What is the output of 10 % 3?", options: ["3", "1", "0", "10"], answer: 1 },
    { question: "Which loop checks condition before execution?", options: ["do-while", "while", "for-each", "None"], answer: 1 },
  ],
  "DBMS": [
    { question: "What does SQL stand for?", options: ["Structured Query Language", "Simple Query Logic", "Standard Query Loop", "None"], answer: 0 },
    { question: "Which normal form removes partial dependency?", options: ["1NF", "2NF", "3NF", "BCNF"], answer: 1 },
    { question: "PRIMARY KEY is a combination of?", options: ["NOT NULL + DEFAULT", "UNIQUE + NOT NULL", "FOREIGN + UNIQUE", "None"], answer: 1 },
    { question: "Which join returns all rows from both tables?", options: ["INNER", "LEFT", "RIGHT", "FULL OUTER"], answer: 3 },
    { question: "ACID stands for?", options: ["Atomicity, Consistency, Isolation, Durability", "Access, Control, Identity, Data", "None", "All of above"], answer: 0 },
  ],
  "Aptitude": [
    { question: "If a train travels 120 km in 2 hours, what is its speed?", options: ["40 km/h", "60 km/h", "80 km/h", "100 km/h"], answer: 1 },
    { question: "What is 15% of 200?", options: ["20", "25", "30", "35"], answer: 2 },
    { question: "A, B can do work in 10, 15 days. Together they finish in?", options: ["5 days", "6 days", "8 days", "12 days"], answer: 1 },
    { question: "Find the next: 2, 6, 12, 20, ?", options: ["28", "30", "32", "36"], answer: 1 },
    { question: "If x + y = 10 and x - y = 4, find x.", options: ["5", "6", "7", "8"], answer: 2 },
  ],
  "Mathematics": [
    { question: "What is the derivative of x²?", options: ["x", "2x", "x²", "2"], answer: 1 },
    { question: "∫ 2x dx = ?", options: ["x²", "x² + C", "2x² + C", "x + C"], answer: 1 },
    { question: "What is the determinant of a 2x2 identity matrix?", options: ["0", "1", "2", "undefined"], answer: 1 },
    { question: "What is log₁₀(1000)?", options: ["2", "3", "4", "10"], answer: 1 },
    { question: "sin(90°) = ?", options: ["0", "0.5", "1", "-1"], answer: 2 },
  ],
  "Operating Systems": [
    { question: "Which scheduling algorithm is non-preemptive?", options: ["Round Robin", "FCFS", "SJF Preemptive", "Priority Preemptive"], answer: 1 },
    { question: "What is a deadlock?", options: ["Fast execution", "Circular wait for resources", "Memory overflow", "CPU idle"], answer: 1 },
    { question: "Which memory management uses pages?", options: ["Segmentation", "Paging", "Swapping", "Compaction"], answer: 1 },
    { question: "What does CPU scheduling decide?", options: ["Which process runs next", "Memory allocation", "Disk speed", "Network routing"], answer: 0 },
    { question: "Thrashing occurs when?", options: ["CPU is idle", "Too many page faults", "Memory is full", "Disk fails"], answer: 1 },
  ],
  "Computer Networks": [
    { question: "Which layer handles routing?", options: ["Transport", "Network", "Data Link", "Application"], answer: 1 },
    { question: "TCP is a __ protocol.", options: ["Connectionless", "Connection-oriented", "Stateless", "None"], answer: 1 },
    { question: "Which protocol is used for email?", options: ["FTP", "HTTP", "SMTP", "DNS"], answer: 2 },
    { question: "IP address belongs to which layer?", options: ["Application", "Transport", "Network", "Physical"], answer: 2 },
    { question: "What is the default port for HTTP?", options: ["21", "25", "80", "443"], answer: 2 },
  ],
  "Python": [
    { question: "Which keyword defines a function in Python?", options: ["func", "def", "function", "define"], answer: 1 },
    { question: "What is the output of len([1,2,3])?", options: ["2", "3", "4", "Error"], answer: 1 },
    { question: "Which is immutable in Python?", options: ["List", "Dictionary", "Tuple", "Set"], answer: 2 },
    { question: "How do you start a comment in Python?", options: ["//", "#", "/*", "--"], answer: 1 },
    { question: "What does 'pip' stand for?", options: ["Python Install Package", "Pip Installs Packages", "Python Index Package", "None"], answer: 1 },
  ],
};

const MockTest = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [currentQ, setCurrentQ] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [history, setHistory] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [customSubjects, setCustomSubjects] = useState<string[]>([]);
  const [newSubject, setNewSubject] = useState("");

  const allSubjects = [...Object.keys(quizBank), ...customSubjects];
  const filteredSubjects = allSubjects.filter((s) =>
    s.toLowerCase().includes(searchQuery.toLowerCase())
  );

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) navigate("/login");
      else {
        setUser(session.user);
        loadHistory(session.user.id);
      }
    });
  }, [navigate]);

  const loadHistory = async (userId: string) => {
    const { data } = await supabase.from("mock_test_results").select("*").eq("user_id", userId).order("created_at", { ascending: false }).limit(20);
    if (data) setHistory(data);
  };

  const addCustomSubject = () => {
    const trimmed = newSubject.trim();
    if (!trimmed) return;
    if (allSubjects.some((s) => s.toLowerCase() === trimmed.toLowerCase())) {
      toast.error("Subject already exists");
      return;
    }
    setCustomSubjects((prev) => [...prev, trimmed]);
    setNewSubject("");
    toast.success(`"${trimmed}" added! (General quiz will be generated)`);
  };

  const removeCustomSubject = (subject: string) => {
    setCustomSubjects((prev) => prev.filter((s) => s !== subject));
  };

  const generateQuestionsForSubject = (subject: string): Question[] => {
    if (quizBank[subject]) return quizBank[subject];
    // Generate generic questions for custom subjects
    return [
      { question: `What is the most fundamental concept in ${subject}?`, options: ["Theory", "Practice", "Both Theory & Practice", "Neither"], answer: 2 },
      { question: `${subject} is best learned through?`, options: ["Reading only", "Practice only", "Reading + Practice", "Memorization"], answer: 2 },
      { question: `Which skill is most important for ${subject}?`, options: ["Critical thinking", "Memorization", "Speed", "Luck"], answer: 0 },
      { question: `How often should you revise ${subject}?`, options: ["Never", "Once a month", "Weekly", "Daily"], answer: 2 },
      { question: `What helps most in mastering ${subject}?`, options: ["Cramming", "Consistent practice", "Skipping basics", "Only reading notes"], answer: 1 },
    ];
  };

  const startQuiz = (subject: string) => {
    setSelectedSubject(subject);
    setCurrentQ(0);
    setSelectedAnswers([]);
    setShowResults(false);
  };

  const selectAnswer = (optionIndex: number) => {
    const newAnswers = [...selectedAnswers];
    newAnswers[currentQ] = optionIndex;
    setSelectedAnswers(newAnswers);
  };

  const nextQuestion = () => {
    const questions = generateQuestionsForSubject(selectedSubject!);
    if (currentQ < questions.length - 1) setCurrentQ(currentQ + 1);
    else finishQuiz();
  };

  const finishQuiz = async () => {
    setShowResults(true);
    const questions = generateQuestionsForSubject(selectedSubject!);
    const correct = selectedAnswers.filter((a, i) => a === questions[i].answer).length;

    if (user) {
      await supabase.from("mock_test_results").insert({
        user_id: user.id,
        subject: selectedSubject!,
        score: correct,
        total: questions.length,
        answers: selectedAnswers,
      } as any);
      loadHistory(user.id);
    }
    toast.success(`Quiz complete! Score: ${correct}/${questions.length}`);
  };

  const deleteResult = async (id: string) => {
    await supabase.from("mock_test_results").delete().eq("id", id);
    toast.success("Deleted");
    if (user) loadHistory(user.id);
  };

  const questions = selectedSubject ? generateQuestionsForSubject(selectedSubject) : [];
  const score = showResults ? selectedAnswers.filter((a, i) => a === questions[i].answer).length : 0;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <main className="max-w-[900px] mx-auto px-4 pt-24 md:pt-20 pb-24 space-y-6">
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={transition}>
          <div className="flex items-center gap-3 mb-1">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[hsl(45,100%,55%)] to-[hsl(330,90%,60%)] flex items-center justify-center">
              <GraduationCap size={20} className="text-white" />
            </div>
            <div>
              <h1 className="text-2xl lg:text-3xl font-bold font-display gradient-text">Mock Tests</h1>
              <p className="text-muted-foreground text-sm">Search subjects, take quizzes, and track your scores</p>
            </div>
          </div>
        </motion.div>

        {!selectedSubject && (
          <>
            {/* Search & Add Subject */}
            <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...transition, delay: 0.05 }}
              className="surface-elevated p-5 space-y-4"
            >
              <div className="relative">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search subjects..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-lg text-sm border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40"
                />
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newSubject}
                  onChange={(e) => setNewSubject(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && addCustomSubject()}
                  placeholder="Add your own subject..."
                  className="flex-1 px-4 py-2 rounded-lg text-sm border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40"
                />
                <button onClick={addCustomSubject}
                  className="flex items-center gap-1 px-4 py-2 rounded-lg text-sm font-medium gradient-primary text-primary-foreground"
                >
                  <Plus size={14} /> Add
                </button>
              </div>
              {customSubjects.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {customSubjects.map((s) => (
                    <span key={s} className="flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium bg-accent text-accent-foreground border border-primary/20">
                      {s}
                      <button onClick={() => removeCustomSubject(s)} className="hover:opacity-70"><X size={12} /></button>
                    </span>
                  ))}
                </div>
              )}
            </motion.div>

            {/* Subject Grid */}
            <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...transition, delay: 0.1 }}
              className="grid grid-cols-2 md:grid-cols-3 gap-4"
            >
              {filteredSubjects.map((subject) => (
                <button key={subject} onClick={() => startQuiz(subject)}
                  className="group surface-elevated p-6 text-left hover:border-primary/40 transition-all"
                >
                  <GraduationCap size={24} className="text-primary mb-3 group-hover:scale-110 transition-transform" />
                  <h3 className="font-bold font-display text-foreground mb-1">{subject}</h3>
                  <span className="text-xs text-muted-foreground">
                    {quizBank[subject] ? `${quizBank[subject].length} questions` : "5 questions (custom)"}
                  </span>
                </button>
              ))}
              {filteredSubjects.length === 0 && (
                <p className="col-span-full text-center text-muted-foreground text-sm py-8">
                  No subjects found. Add your own above!
                </p>
              )}
            </motion.div>

            {/* History */}
            {history.length > 0 && (
              <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...transition, delay: 0.15 }}
                className="surface-elevated p-6"
              >
                <span className="text-label text-muted-foreground block mb-4">📊 Past Results</span>
                <div className="space-y-2">
                  {history.map((h) => (
                    <div key={h.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 border border-border">
                      <div className="flex items-center gap-3">
                        <span className={`text-lg font-bold ${h.score / h.total >= 0.6 ? "text-neon-green" : h.score / h.total >= 0.4 ? "text-warning" : "text-destructive"}`}>
                          {h.score}/{h.total}
                        </span>
                        <span className="text-sm text-foreground">{h.subject}</span>
                        <span className="text-xs text-muted-foreground">{new Date(h.created_at).toLocaleDateString()}</span>
                      </div>
                      <button onClick={() => deleteResult(h.id)} className="text-muted-foreground hover:text-destructive transition-colors">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </>
        )}

        {/* Quiz */}
        {selectedSubject && !showResults && (
          <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={transition}
            className="surface-elevated p-6 lg:p-8"
          >
            <div className="flex items-center justify-between mb-6">
              <span className="text-label text-muted-foreground">{selectedSubject} – Question {currentQ + 1}/{questions.length}</span>
              <div className="flex gap-1">
                {questions.map((_, i) => (
                  <div key={i} className={`w-6 h-1.5 rounded-full ${i === currentQ ? "gradient-primary" : i < currentQ ? "bg-neon-green" : "bg-secondary"}`} />
                ))}
              </div>
            </div>

            <h2 className="text-xl font-bold font-display text-foreground mb-6">{questions[currentQ].question}</h2>

            <div className="space-y-3 mb-8">
              {questions[currentQ].options.map((option, i) => (
                <button key={i} onClick={() => selectAnswer(i)}
                  className={`w-full text-left p-4 rounded-lg border transition-all ${
                    selectedAnswers[currentQ] === i
                      ? "gradient-primary text-primary-foreground border-primary/30"
                      : "bg-secondary/50 border-border text-foreground hover:border-primary/40"
                  }`}
                >
                  <span className="font-mono text-xs mr-3 opacity-60">{String.fromCharCode(65 + i)}</span>
                  {option}
                </button>
              ))}
            </div>

            <div className="flex gap-3">
              <button onClick={nextQuestion} disabled={selectedAnswers[currentQ] === undefined}
                className="gradient-primary text-primary-foreground px-6 py-3 rounded-lg font-bold uppercase text-sm transition-all hover:shadow-lg hover:shadow-primary/30 active:scale-95 disabled:opacity-30 glow-primary"
              >
                {currentQ < questions.length - 1 ? "Next Question" : "Finish Quiz"}
              </button>
              <button onClick={() => setSelectedSubject(null)}
                className="border border-border px-4 py-3 rounded-lg text-sm text-muted-foreground hover:text-foreground transition-all"
              >
                Quit
              </button>
            </div>
          </motion.div>
        )}

        {/* Results */}
        {showResults && (
          <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={transition}
            className="surface-elevated p-6 lg:p-8 text-center"
          >
            <Trophy size={48} className={`mx-auto mb-4 ${score / questions.length >= 0.6 ? "text-neon-green" : "text-warning"}`} />
            <h2 className="text-3xl font-bold font-display gradient-text mb-2">
              {score}/{questions.length}
            </h2>
            <p className="text-muted-foreground mb-6">
              {score / questions.length >= 0.8 ? "Excellent! You nailed it! 🎉" :
                score / questions.length >= 0.6 ? "Good job! Keep practicing! 💪" :
                  "Keep studying, you'll improve! 📚"}
            </p>

            <div className="space-y-2 mb-6 text-left max-w-lg mx-auto">
              {questions.map((q, i) => (
                <div key={i} className={`flex items-start gap-3 p-3 rounded-lg ${
                  selectedAnswers[i] === q.answer ? "bg-neon-green/5 border border-neon-green/20" : "bg-destructive/5 border border-destructive/20"
                }`}>
                  {selectedAnswers[i] === q.answer ? (
                    <CheckCircle2 size={18} className="text-neon-green mt-0.5 flex-shrink-0" />
                  ) : (
                    <XCircle size={18} className="text-destructive mt-0.5 flex-shrink-0" />
                  )}
                  <div>
                    <span className="text-sm text-foreground">{q.question}</span>
                    {selectedAnswers[i] !== q.answer && (
                      <span className="text-xs text-neon-green block mt-1">Correct: {q.options[q.answer]}</span>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-center gap-3">
              <button onClick={() => startQuiz(selectedSubject!)}
                className="flex items-center gap-2 gradient-primary text-primary-foreground px-6 py-3 rounded-lg font-bold uppercase text-sm glow-primary"
              >
                <RotateCcw size={16} /> Retry
              </button>
              <button onClick={() => setSelectedSubject(null)}
                className="border border-border px-6 py-3 rounded-lg text-sm text-muted-foreground hover:text-foreground transition-all"
              >
                Back to Topics
              </button>
            </div>
          </motion.div>
        )}
      </main>
      <AiAssistant />
    </div>
  );
};

export default MockTest;
