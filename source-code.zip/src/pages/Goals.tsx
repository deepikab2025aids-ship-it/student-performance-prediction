import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Target, Plus, Trash2, CheckCircle2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import Navbar from "@/components/Navbar";
import AiAssistant from "@/components/AiAssistant";

const transition = { duration: 0.6, ease: [0.19, 1, 0.22, 1] as const };

interface Goal {
  id: string;
  subject: string;
  target_score: number;
  current_score: number;
  deadline: string | null;
  created_at: string;
}

const Goals = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [newGoal, setNewGoal] = useState({ subject: "", target_score: 80, current_score: 0, deadline: "" });
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) navigate("/login");
      else {
        setUser(session.user);
        loadGoals(session.user.id);
      }
    });
  }, [navigate]);

  const loadGoals = async (userId: string) => {
    const { data } = await supabase.from("goals").select("*").eq("user_id", userId).order("created_at", { ascending: false });
    if (data) setGoals(data as Goal[]);
  };

  const addGoal = async () => {
    if (!newGoal.subject || !user) { toast.error("Enter a subject"); return; }
    const { error } = await supabase.from("goals").insert({
      user_id: user.id,
      subject: newGoal.subject,
      target_score: newGoal.target_score,
      current_score: newGoal.current_score,
      deadline: newGoal.deadline || null,
    } as any);
    if (error) toast.error("Failed to add goal");
    else {
      toast.success("Goal added!");
      setNewGoal({ subject: "", target_score: 80, current_score: 0, deadline: "" });
      setShowForm(false);
      loadGoals(user.id);
    }
  };

  const updateProgress = async (goal: Goal, newScore: number) => {
    await supabase.from("goals").update({ current_score: newScore } as any).eq("id", goal.id);
    if (user) loadGoals(user.id);
    if (newScore >= goal.target_score) toast.success("🎉 Goal achieved!");
  };

  const deleteGoal = async (id: string) => {
    await supabase.from("goals").delete().eq("id", id);
    toast.success("Goal removed");
    if (user) loadGoals(user.id);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <main className="max-w-[900px] mx-auto px-4 pt-24 md:pt-20 pb-24 space-y-6">
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={transition}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[hsl(200,95%,55%)] to-[hsl(265,90%,60%)] flex items-center justify-center">
                <Target size={20} className="text-white" />
              </div>
              <div>
                <h1 className="text-2xl lg:text-3xl font-bold font-display gradient-text">Goal Setting</h1>
                <p className="text-muted-foreground text-sm">Set targets and track your progress</p>
              </div>
            </div>
            <button onClick={() => setShowForm(!showForm)}
              className="flex items-center gap-2 gradient-primary text-primary-foreground px-4 py-2 rounded-lg font-bold uppercase text-xs transition-all hover:shadow-lg hover:shadow-primary/30 active:scale-95 glow-primary"
            >
              <Plus size={14} /> New Goal
            </button>
          </div>
        </motion.div>

        {/* Add Goal Form */}
        {showForm && (
          <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={transition}
            className="surface-elevated p-6"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="flex flex-col gap-2">
                <label className="text-label text-muted-foreground">Subject</label>
                <input type="text" value={newGoal.subject} onChange={(e) => setNewGoal({ ...newGoal, subject: e.target.value })}
                  placeholder="e.g. Mathematics"
                  className="bg-secondary border border-border px-4 py-3 rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all placeholder:text-muted-foreground/40"
                />
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-label text-muted-foreground">Deadline</label>
                <input type="date" value={newGoal.deadline} onChange={(e) => setNewGoal({ ...newGoal, deadline: e.target.value })}
                  className="bg-secondary border border-border px-4 py-3 rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all"
                />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="flex flex-col gap-2">
                <label className="text-label text-muted-foreground">Target Score: {newGoal.target_score}%</label>
                <input type="range" min={10} max={100} value={newGoal.target_score}
                  onChange={(e) => setNewGoal({ ...newGoal, target_score: parseInt(e.target.value) })}
                  className="accent-primary"
                />
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-label text-muted-foreground">Current Score: {newGoal.current_score}%</label>
                <input type="range" min={0} max={100} value={newGoal.current_score}
                  onChange={(e) => setNewGoal({ ...newGoal, current_score: parseInt(e.target.value) })}
                  className="accent-primary"
                />
              </div>
            </div>
            <button onClick={addGoal}
              className="gradient-primary text-primary-foreground px-6 py-3 rounded-lg font-bold uppercase text-sm transition-all hover:shadow-lg hover:shadow-primary/30 active:scale-95 glow-primary"
            >
              Add Goal
            </button>
          </motion.div>
        )}

        {/* Goals List */}
        <div className="space-y-4">
          {goals.length === 0 && (
            <div className="surface-elevated p-12 text-center">
              <Target size={48} className="text-muted-foreground/30 mx-auto mb-4" />
              <p className="text-muted-foreground">No goals set yet. Click "New Goal" to get started!</p>
            </div>
          )}
          {goals.map((goal, i) => {
            const progress = Math.min((goal.current_score / goal.target_score) * 100, 100);
            const achieved = goal.current_score >= goal.target_score;
            const daysLeft = goal.deadline ? Math.ceil((new Date(goal.deadline).getTime() - Date.now()) / 86400000) : null;

            return (
              <motion.div key={goal.id} initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }}
                transition={{ ...transition, delay: i * 0.05 }}
                className={`surface-elevated p-5 ${achieved ? "border-neon-green/30" : ""}`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    {achieved && <CheckCircle2 size={20} className="text-neon-green" />}
                    <div>
                      <h3 className="font-bold font-display text-foreground">{goal.subject}</h3>
                      <div className="flex items-center gap-3 mt-0.5">
                        <span className="text-xs text-muted-foreground">
                          Target: {goal.target_score}% · Current: {goal.current_score}%
                        </span>
                        {daysLeft !== null && (
                          <span className={`text-xs ${daysLeft > 7 ? "text-neon-green" : daysLeft > 0 ? "text-warning" : "text-destructive"}`}>
                            {daysLeft > 0 ? `${daysLeft} days left` : "Past deadline"}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <button onClick={() => deleteGoal(goal.id)} className="text-muted-foreground hover:text-destructive transition-colors">
                    <Trash2 size={14} />
                  </button>
                </div>

                {/* Progress bar */}
                <div className="w-full h-3 rounded-full bg-secondary overflow-hidden mb-3">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    transition={{ duration: 1, ease: "easeOut" }}
                    className={`h-full rounded-full ${achieved ? "bg-neon-green" : "bg-gradient-to-r from-primary to-accent"}`}
                  />
                </div>

                {/* Update progress */}
                {!achieved && (
                  <div className="flex items-center gap-3">
                    <span className="text-xs text-muted-foreground">Update progress:</span>
                    <input
                      type="range" min={0} max={100} value={goal.current_score}
                      onChange={(e) => updateProgress(goal, parseInt(e.target.value))}
                      className="flex-1 accent-primary"
                    />
                    <span className="text-sm font-bold gradient-text">{goal.current_score}%</span>
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>
      </main>
      <AiAssistant />
    </div>
  );
};

export default Goals;
